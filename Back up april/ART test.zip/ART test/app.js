// Set the dimensions and margins of the graph
var margin = { top: 10, right: 10, bottom: 10, left: 10 },
    width =800 - margin.left - margin.right,
    height = 800- margin.top - margin.bottom,
    innerRadius = 80,
    outerRadius = Math.min(width, height) / 2;

    function getRandomColor() {
        var letters = '0123456789ABCDEF';
        var color = '#';
        for (var i = 0; i < 6; i++) {
            color += letters[Math.floor(Math.random() * 16)];
        }
        return color;
    }

// Append the SVG object to the body of the page
var svg = d3.select("#my_dataviz")
    .append("svg")
    .attr("width", width + margin.left + margin.right)
    .attr("height", height + margin.top + margin.bottom)
    .append("g")
    .attr("transform", "translate(" + width / 2 + "," + (height / 2) + ")");
  let asteroidNames = []; 
async function fetchDataAndDraw() {   var tooltip = d3.select("body")

    try {
        let asteroidData = await fetchAstData2();

        // Filter data for asteroids orbiting Earth
        let earthOrbitAsteroids = asteroidData.near_earth_objects.filter(asteroid => {
            return asteroid.close_approach_data && asteroid.close_approach_data.length > 0 &&
                asteroid.close_approach_data.some(approach => approach.orbiting_body === 'Earth');
        });

        // X scale (using scaleBand for approach dates)
        var x = d3.scaleBand()
            .domain(earthOrbitAsteroids.reduce((dates, asteroid) => {
                dates.push(...asteroid.close_approach_data.map(approach => approach.close_approach_date));
                return dates;
            }, []))
            .range([0, 2 * Math.PI])
            .align(0);

        // Y scale
        var y = d3.scaleRadial()
            .range([innerRadius, outerRadius])
            .domain([0, d3.max(earthOrbitAsteroids, function (d) {
                return d3.max(d.close_approach_data, function (approach) {
                    return parseFloat(approach.miss_distance.kilometers);
                });
            })]);
          
        svg.append("g")
            .selectAll("g")
            .data(earthOrbitAsteroids)
            .enter().append("g")
            .selectAll("path")
            .data(function (d) {// console.log(d)
                asteroidNames.push(d.asteroid_name); //
               // console.log(d.close_approach_data)
                return d.close_approach_data;
                
            })
            .enter().append("path")
            .attr("fill", function (d) {
                return getRandomColor(); // Assign a unique random color to each asteroid
            })
            .attr("d", d3.arc()
                .innerRadius(innerRadius)
                .outerRadius(function (d) {
                    return y(parseFloat(d.miss_distance.kilometers));
                })
                .startAngle(function (d) {
                    return x(d.close_approach_date);
                })
                .endAngle(function (d) {
                    return x(d.close_approach_date) + x.bandwidth();
                })
                .padAngle(0.01)
                .padRadius(innerRadius)) .on("mouseover", (event, d) => showTooltipp(event, d))
                .on('mousemove',moveTooltipp)    
                .on("mouseout", hideTooltipp)
                   
         ; var legend = svg.selectAll(".legend")
         .data(earthOrbitAsteroids)
         .enter().append("g")
         .attr("class", "legend")
         .attr("transform", function (d, i) {
             return "translate(0," + i * 20 + ")";
         });
 
     legend.append("rect")
         .attr("x", width / 2 - 18)
         .attr("width", 18)
         .attr("height", 18)
         .style("fill", function (d) {
             return getRandomColor(); // Assign the same color to legend as the corresponding asteroid
         });
         legend.append("text")
         .attr("x", width / 2 + 5)
         .attr("y", 9)
         .attr("dy", ".35em")
         .style("text-anchor", "start")
         .text(function (d) {
             return d.name; // Display the name of the corresponding asteroid next to the color
         });
    } catch (error) {
        // Handle any errors that occurred during the data retrieval
        console.error('Data retrieval error:', error);
    }
}

let tooltipp = d3.select('#roott')
.append('p')
.attr("stroke","blue" ,"2px") 

.style('opacity',0)
.style("width", " 180px")
.style("border-radius", "5px")
.attr("font-size" , "8px")
.style('padding',"20px")
.style("background-color", '#000')
.style("color",'#fff')
.style("position", "relative");
function showTooltipp(event, d) {
    if (d) { 


        let asteroidIndex = asteroidNames.indexOf(d.miss_Distance);
            console.log(asteroidName[8])
        let asteroidName = asteroidIndex !== -1 ? asteroidNames[asteroidIndex] : 'N/A';

        let missDistance = d.miss_distance && d.miss_distance.kilometers !== undefined
            ? `${d.miss_distance.kilometers} km`
            : 'N/A';

        tooltipp.transition().duration(200)
            .style('opacity', 1)
            .style('left', d3.pointer(event)[0] + 200 + "px")
            .style('top', d3.pointer(event)[1] - 200 + "px")
            tooltipp.html(`<strong>Name:</strong> ${asteroidName[8]}<br>
                   <strong>Closest Approach Date:</strong> ${d.close_approach_date}<br>
                   <strong>Miss Distance:</strong> ${missDistance}`);
    } else {
        // Handle the case where d is undefined
        tooltipp.transition().duration(200)
            .style('opacity', 1)
            .style('left', d3.pointer(event)[0] + 200 + "px")
            .style('top', d3.pointer(event)[1] - 200 + "px")
            tooltipp.html(`<strong>Name:</strong> N/A<br>
                   <strong>Closest Approach Date:</strong> N/A<br>
                   <strong>Miss Distance:</strong> N/A`);
    }
}

  function moveTooltipp(){
    tooltipp.style('left', d3.pointer(event)[0] +200+'px')
    .style('top',d3.pointer(event)[1]-200+'px')
  }
  function hideTooltipp(){
    tooltipp.style('opacity',0);
  }
// Call the function to fetch data and draw the circular bar plot
fetchDataAndDraw();
