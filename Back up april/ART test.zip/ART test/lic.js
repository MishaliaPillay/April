const svgWidth = 800;
const svgHeight = 400;
const circleRadius = 100;
const animationDuration = 5000;

const svg = d3.select("#visualization-container")
  .append("svg")
  .attr("width", svgWidth)
  .attr("height", svgHeight);

// Function to update the graph based on asteroid data
function updateGraph(data) {
  // Clear previous visualization
  svg.selectAll("*").remove();

  // Extract velocities and closest approach dates
  const velocities = [];
  const approachDates = [];

  data.near_earth_objects.forEach(asteroid => {
    asteroid.close_approach_data.forEach(approach => {
      velocities.push(approach.relative_velocity.kilometers_per_second);
      approachDates.push(new Date(approach.close_approach_date_full));
    });
  });

  // Set up scales
  const xScale = d3.scaleTime()
    .domain(d3.extent(approachDates))
    .range([0, svgWidth]);

  const yScale = d3.scaleLinear()
    .domain([0, d3.max(velocities)])
    .range([svgHeight, 0]);

  // Draw lines from the center of the circle to points on the circle's circumference
  const lines = svg.selectAll("line")
    .data(velocities)
    .enter()
    .append("line")
    .attr("x1", svgWidth / 2)
    .attr("y1", svgHeight / 2)
    .attr("x2", (d, i) => svgWidth / 2 + circleRadius * Math.cos(i * 2 * Math.PI / velocities.length))
    .attr("y2", (d, i) => svgHeight / 2 + circleRadius * Math.sin(i * 2 * Math.PI / velocities.length))
    .attr("stroke", "blue")
    .attr("stroke-opacity", 0.5)
    .attr("stroke-width", d => d / 10); // Adjust line width based on velocity

  // Animate lines based on relative velocity
  lines.transition()
    .duration(animationDuration)
    .attr("x2", (d, i) => svgWidth / 2 + (circleRadius + d * 10) * Math.cos(i * 2 * Math.PI / velocities.length))
    .attr("y2", (d, i) => svgHeight / 2 + (circleRadius + d * 10) * Math.sin(i * 2 * Math.PI / velocities.length));
}



updateGraph();
