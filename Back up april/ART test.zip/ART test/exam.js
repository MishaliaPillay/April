


// Event listener for the "Fast" button
document.getElementById('fast').addEventListener('click', showFastAsteroids);

// Event listener for the "Slow" button
document.getElementById('slow').addEventListener('click', showSlowAsteroids);

// Function to filter and display asteroids above 15 km/s
function showFastAsteroids() {
    const fastAsteroids = approachData.filter(d => d.relativeVelocity > 15);
    updateGraph(fastAsteroids);
}

// Function to filter and display asteroids below 15 km/s
function showSlowAsteroids() {
    const slowAsteroids = approachData.filter(d => d.relativeVelocity <= 15);
    updateGraph(slowAsteroids);
}

// Initial call to display all asteroids
updateGraph(approachData);





function updateGraph(data) {
    const approachData = data; 
    const svgWidth = 800; // Set your desired SVG width
    const svgHeight = 400; // Set your desired SVG height
    const padding = { top: 40, right: 20, bottom: 20, left: 50 }; // Set padding values

    const svg = d3.select("#visualization")
        .attr("width", svgWidth)
        .attr("height", svgHeight);

     // Extract all miss distances and relative velocities from all closest approach dates
     const missData = data.near_earth_objects.flatMap(asteroid => {
        return asteroid.close_approach_data.map(approach => ({
            missDistance: approach.miss_distance.kilometers,
            relativeVelocity: approach.relative_velocity.kilometers_per_second
        }));
    });

    // Find the maximum and minimum relative velocities
    const maxVelocity = d3.max(missData, d => d.relativeVelocity);
    const minVelocity = d3.min(missData, d => d.relativeVelocity);

    // Calculate an appropriate interval based on the range of relative velocities
    const interval = d3.scaleLinear()
        .domain([minVelocity, maxVelocity])
        .range([500, 2000]); // Set a range of intervals based on velocities (adjust as needed)

    // Create a scale for the y-axis based on the fastest and lowest velocities
    const yScale = d3.scaleLinear()
        .domain([minVelocity, maxVelocity])
        .range([svgHeight - padding.bottom, padding.top]);

    // Create y-axis
    const yAxis = d3.axisLeft(yScale)
        .ticks(20)
        .tickFormat(d3.format(".2s"));

    // Append y-axis to the SVG
    svg.selectAll(".y-axis").remove();
    svg.append("g")
        .attr("class", "y-axis")
        .attr("transform", `translate(${padding.left}, 0)`)
        .call(yAxis);

    // Add a circle in the center
    const centerX = (svgWidth - padding.left - padding.right) / 2 + padding.left;
    const centerY = (svgHeight - padding.top - padding.bottom) / 2 + padding.top;

    // Create horizontal lines representing miss distances with gradient
    const lines = svg.selectAll("line")
        .data(missData)
        .enter().append("line")
        .attr("x1", padding.left)
        .attr("y1", d => yScale(d.relativeVelocity))
        .attr("x2", padding.left) // Initial x2 position is the same as x1
        .attr("y2", d => yScale(d.relativeVelocity))
        .attr("stroke-width", 2)
        .attr("stroke-dasharray", "5,5"); // Set dash pattern

    // Add a gradient for each line
    lines.each(function (d, i) {
        const line = d3.select(this);
        const gradientId = "line-gradient-" + i;

        const gradient = svg.append("defs")
            .append("linearGradient")
            .attr("id", gradientId)
            .attr("gradientUnits", "userSpaceOnUse")
            .attr("x1", padding.left)
            .attr("y1", yScale(d.relativeVelocity))
            .attr("x2", svgWidth - padding.right)
            .attr("y2", yScale(d.relativeVelocity));

        gradient.append("stop")
            .attr("offset", "0%")
            .attr("stop-color", "teal");

        gradient.append("stop")
            .attr("offset", "100%")
            .attr("stop-color", "red");

        line.attr("stroke", "url(#" + gradientId + ")");
    });

    // Add tooltips
    lines.append("title")
        .text(d => `Miss Distance: ${d.missDistance} km\nRelative Velocity: ${d.relativeVelocity} km/s`);

   // Create a function to move lines with variable duration
   function moveLines() {
    lines.transition()
        .duration(d => interval(d.relativeVelocity)) // Adjust the duration based on relative velocity
        .attr("x2", svgWidth - padding.right) // Move x2 to the right edge of the SVG
        .transition()
        .duration(0) // Reset duration to 0 for a smooth transition
        .attr("x1", padding.left) // Reset x1 to the left edge of the SVG
        .attr("x2", padding.left); // Reset x2 to the left edge of the SVG
}

// Call moveLines function continuously
setInterval(moveLines, 3000); // Move lines every 3000 milliseconds (3 seconds)
}

// Example usage:
// Call updateGraph with your data
// updateGraph(yourData);
